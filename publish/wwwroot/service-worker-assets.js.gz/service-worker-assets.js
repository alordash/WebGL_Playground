﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-8aM9R9K90X6h+KPDW4OzrEh071mAs7dvAQxjBxAZQAc=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-1CNqEhk+AnCAflOFr+ihxZNjmfKMaMPF4UJl5YFaPyQ=",
      "url": "css\/MyStyles.css"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-x5KOEL\/4WNcHaphH2YCtcnshl28yi\/\/joWwEH\/wXgNo=",
      "url": "Data\/image1.jpg"
    },
    {
      "hash": "sha256-\/Eu5AC2xTfJl6pHeQ4oOCFXJXwh6bcicEg2U+SwdQNQ=",
      "url": "Data\/image2.jpg"
    },
    {
      "hash": "sha256-cSsk98GWT3aKKu5fS3WPcGdBUFov4jLRlEb20wS3I0w=",
      "url": "Data\/zb.jpg"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-3a2R4itF8H+ZY4tq+6okZcrt6tD28W1uEmI+RvRYHgQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fNqBR9hQbq2vc2McmP5Du4GvA++fFi0BdjnIf5sdQOs=",
      "url": "js\/JSFuncs.js"
    },
    {
      "hash": "sha256-iejnQmAbRrHps\/ZzzAvBknd7KQO7FaXm0lQ6d5LRpMo=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-7JUvImZ\/DalAPsqUddnaozJZXmYV8R\/\/HvJAb1sKERM=",
      "url": "Shaders\/imageConvolution.frag"
    },
    {
      "hash": "sha256-OPEbeNrMTBV0G1h4KipcHTxSEx+EVR1uJGj\/N8LmBTs=",
      "url": "Shaders\/imageConvolution.vert"
    },
    {
      "hash": "sha256-gzHFGVonzwPDW\/LciLuiDCxbzYpU7u2XwitEiUWw224=",
      "url": "Shaders\/interpolation.frag"
    },
    {
      "hash": "sha256-1y7EiiZcfqo\/5ifaJQ+cd2PPEjsXSMyApQt8RGdDqak=",
      "url": "Shaders\/interpolation.vert"
    },
    {
      "hash": "sha256-gzHFGVonzwPDW\/LciLuiDCxbzYpU7u2XwitEiUWw224=",
      "url": "Shaders\/shader.frag"
    },
    {
      "hash": "sha256-C3JMHODJKdmmDW9vJ8pDvHBTL9bOujevjNGNi7EOw7Y=",
      "url": "Shaders\/shader.vert"
    },
    {
      "hash": "sha256-4ahtb2Iu9bZWXccqIJpnsLYlGX1NywS9IVrIfxRJ9H0=",
      "url": "Shaders\/voronoi.frag"
    },
    {
      "hash": "sha256-wnE3cQh13V0PiH4M2ukdY0Og0k\/fcBmvtED7YB1Uv4k=",
      "url": "Shaders\/voronoi.vert"
    },
    {
      "hash": "sha256-01WrBxcALPsQfi2mjDGe6GtkmTs1HasekOpHcq8ia34=",
      "url": "_framework\/WebGL_Playground_Site.dll"
    },
    {
      "hash": "sha256-TrW1uaSNUS+J8xVJErxIf1NQuNC7kn50KzMYYF\/4JtM=",
      "url": "_framework\/Blazor.Extensions.Canvas.JS.dll"
    },
    {
      "hash": "sha256-W20pWMXQg2yTv0w4VJhrjCJKNRYe3PiUU9S76XipNe8=",
      "url": "_framework\/Blazor.Extensions.Canvas.dll"
    },
    {
      "hash": "sha256-Qs05+jXr6ExLqKHmpkMovKl\/fBhD8otN+T2ZtL9Vlrc=",
      "url": "_framework\/Microsoft.AspNetCore.Authorization.dll"
    },
    {
      "hash": "sha256-x4ddqjUyODALx4h32YVXlEiGn0AU+nR1KVVO2AWPo7c=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-BmRcmiSxXRVnZk0v6cERnXlUBpHGJxp\/Vt6F37Oce44=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Forms.dll"
    },
    {
      "hash": "sha256-osuxV0vLq0q\/NuTE9TaunquGbzQvcBu8J+WNPypxK1M=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-cEIzHVRsSMNOBy7fDnclumjrMrq2Jg2anjYlzx20ID4=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-46zrnxdS2XI38p91KRTmeOgJZSwfilTFhcRur66EaZk=",
      "url": "_framework\/Microsoft.AspNetCore.Metadata.dll"
    },
    {
      "hash": "sha256-x9zYR1t1is\/fStNpBiQnXyPdMpLLcQcra3w4RXGSg4o=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-NYecKM0ZpUvzj4spvgi6xUu80rkx8PX7fiRok\/BNaHw=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-JFLIykah3r5WjvztBuVIaMM9wfVswDM+On6k\/QVgeeg=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Binder.dll"
    },
    {
      "hash": "sha256-5tCmu87qBh0Xgsp\/dG\/x9WHctz\/J8YBmCHjt+PA6dn0=",
      "url": "_framework\/Microsoft.Extensions.Configuration.FileExtensions.dll"
    },
    {
      "hash": "sha256-OM0kYGXmRhgJOUP2Vf86pt4Ss7QB2\/fLPtfL4+p0Xz8=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-W\/Xy5S\/Zin\/Xx5oGhOYdTkJLd1mRSie5cNH7qKtU7ZA=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-D9y5RXbA\/sEzwk6cnGbGMKQv87bvOEEVycrLUTe0lGU=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-aUKLFqSgB\/hwZc41dLVKoRSKRghShpfQPVMhoRzpz5M=",
      "url": "_framework\/Microsoft.Extensions.FileProviders.Abstractions.dll"
    },
    {
      "hash": "sha256-Cvhy7j568oPzBQKhakMhNkDr5tQBxE0LaY1wukd0Ll0=",
      "url": "_framework\/Microsoft.Extensions.FileProviders.Physical.dll"
    },
    {
      "hash": "sha256-xrpMDo35bgwz\/m\/kwUvL9SAOxyEgSSwO57RiuhILHgI=",
      "url": "_framework\/Microsoft.Extensions.FileSystemGlobbing.dll"
    },
    {
      "hash": "sha256-VlsKv5zXgdK0MrYHXr9XlUCXwuwNI7AUI\/C1PEFXcz4=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-9UNtwDMFW86VtnTtJFk9xcc1hCnXFGXccFv3SkbgYy0=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-YfK6Zl0RmlJUqBJD7Khy7u4HEW2DRne0VSiqA6Yqs0U=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-f2PgoftqEkKRuuiAk6S1MHygOuqZBHzB0HOB3vR93TU=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-tDvn5GW+7NGvLe6n9\/tTh669tukuSpdtM4Oxhjs9GNY=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-TZF2KGZRSev\/gMKjN7GoplW2xZPrK+yI4lECdonDwC4=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-3ET+mpR7F058YRj9YaLHOVXBqOW6iUxtIpeiKPYw4PA=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-2cIPsBePHRi3fKXTdJQAY1yT0vuYVgy4KjmisZdzdK4=",
      "url": "WebGL_Playground_Site.styles.css"
    },
    {
      "hash": "sha256-9Z\/+MBCfTH\/eE5e5aYMGZ+WzaJLk8tl2MwD\/AGVvifc=",
      "url": "_content\/Blazor.Extensions.Canvas\/blazor.extensions.canvas.js"
    },
    {
      "hash": "sha256-NbU4E8FwDa1gfyW49pEP6ofBqjp9SbdtnZEeSaR47Y0=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-dl8FVRvWOJfOtzIC\/x66QNnBNsT9cAOMrn22GB8fJ8U=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "ozGEMtdQ"
};
